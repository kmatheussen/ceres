\ instruments.fs -- instrument definitions for GFM -*- forth -*-

\ Copyright (C) 2003 Michael Scholz

\ Author: Michael Scholz <scholz-micha@gmx.de>
\ Created: Tue Aug 12 16:25:33 CEST 2003
\ Last: Fri Oct 03 15:23:12 CEST 2003
\ Ident: $Id: instruments.fs,v 1.42 2003/10/03 13:23:18 mike Exp $

\ This file is part of GFM Gforth Music.

\ This program is free software; you can redistribute it and/or
\ modify it under the terms of the GNU General Public License as
\ published by the Free Software Foundation; either version 2 of
\ the License, or (at your option) any later version.

\ This program is distributed in the hope that it will be
\ useful, but WITHOUT ANY WARRANTY; without even the implied
\ warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
\ PURPOSE.  See the GNU General Public License for more details.

\ You should have received a copy of the GNU General Public
\ License along with this program; if not, write to the Free
\ Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
\ MA 02111-1307 USA

\ Commentary:

\ resflt-test
\ fofins-test
\ formant-test
\ touch-tone-test
\ rt-touch-tone-test
\ fm-insect-test
\ fm-noise-test
\ pqw-test
\ anoi-test
\ pluck-test

\ Instruments:

\ jc-reverb
\ nrev
\ fm1
\ fm2
\ violin
\ violin-args
\ rt-violin
\ cascade
\ bird
\ bigbird
\ resflt-cos
\ resflt-noise
\ fofins
\ cross-synthesis
\ touch-tone
\ rt-touch-tone
\ fm-insect
\ fm-noise
\ pqw
\ anoi
\ anoi-0
\ pluck

\ Code:

require gfm.fs
only forth also definitions also GFMusic also CLM-Sndlib

\ This may simulate keyword args for instruments (see violin-args and
\ resflt below).
struct
    float% field ins-fm-index
    float% field ins-degree
    float% field ins-distance
    cell% field ins-ind-env
end-struct instrument%

: :default! { size -- gen }
    size %allot { gen }
    1e gen ins-fm-index f!
    90e random gen ins-degree f!
    1e gen ins-distance f!
    0e 1e 100e 1e 4 make-farray gen ins-ind-env !
    gen
;
: :default { -- gen } instrument% :default! ;
: :fm-index@ { gen -- r } gen ins-fm-index f@ ;
: :fm-index! { gen f: val -- gen } val gen ins-fm-index f! gen ;
: :ind-env@ { gen -- w } gen ins-ind-env @ ;
: :ind-env! { gen w -- gen } w gen ins-ind-env ! gen ;
: :degree@ { gen -- r } gen ins-degree f@ ;
: :degree! { gen f: val -- gen } val gen ins-degree f! gen ;
: :distance@ { gen -- r } gen ins-distance f@ ;
: :distance! { gen f: val -- gen } val gen ins-distance f! gen ;

\ clm-2/jcrev.ins
instrument: jc-reverb { f: start f: dur }
    -0.7e 0.7e 1051 make-all-pass { allpass1 }
    -0.7e 0.7e 337 make-all-pass { allpass2 }
    -0.7e 0.7e 113 make-all-pass { allpass3 }
    0.742e 4799 make-comb { comb1 }
    0.733e 4999 make-comb { comb2 }
    0.715e 5399 make-comb { comb3 }
    0.697e 5801 make-comb { comb4 }
    13 srate@ 1000 */ make-delay { outdel1 }
    *output* channels@ { chans }
    *reverb* channels@ { rev-chans }
    chans 2 = if 11 srate@ 1000 */ make-delay else false then { outdel2 }
    *verbose* if ." \  jc-reverb on " rev-chans . ." in and " chans . ." out channels" cr then
    0e { f: allpass-sum }
    0e { f: all-sums }
    start dur run
	0e rev-chans 0 u+do j i *reverb* in-any f+ loop
	allpass1 all-pass-1  allpass2 all-pass-1  allpass3 all-pass-1 to allpass-sum
	allpass-sum comb1 comb-1  allpass-sum comb2 comb-1  f+
	allpass-sum comb3 comb-1  f+  allpass-sum comb4 comb-1  f+ to all-sums
	all-sums outdel1 delay-1  i outa-0
	chans 2 = if all-sums outdel2 delay-1  i outb-0 then
    loop
    allpass1 mus-free
    allpass2 mus-free
    allpass3 mus-free
    comb1 mus-free
    comb2 mus-free
    comb3 mus-free
    comb4 mus-free
    outdel1 mus-free
    outdel2 ?dup-if mus-free then
;instrument

\ clm-2/nrev.ins
instrument: nrev { f: start f: dur }
    1.09e { f: reverb-factor }
    0.7e { f: lp-coeff }
    mus-srate@ 25641e f/ { f: srscale }
    1433 1601 1867 2053 2251 2399 347 113 37 59 53 43 37 29 19 15 make-array { dly-len }
    dly-len array-length 0 u+do
	i dly-len array@ s>f srscale f* floor f>s { val }
	val 2 mod 0= if val 1+ to val then
	begin val prime 0= while val 2 + to val repeat
	val i dly-len array!
    loop
    0.822e reverb-factor f* 0 dly-len array@ make-comb { comb1 }
    0.802e reverb-factor f* 1 dly-len array@ make-comb { comb2 }
    0.773e reverb-factor f* 2 dly-len array@ make-comb { comb3 }
    0.753e reverb-factor f* 3 dly-len array@ make-comb { comb4 }
    0.753e reverb-factor f* 4 dly-len array@ make-comb { comb5 }
    0.733e reverb-factor f* 5 dly-len array@ make-comb { comb6 }
    lp-coeff lp-coeff 1e f- make-one-pole { low }
    *output* channels@ { chans }
    *reverb* channels@ { rev-chans }
    chans 1 > { chan2 }
    chans 4 = { chan4 }
    -0.7e 0.7e 6 dly-len array@ make-all-pass { allpass1 }
    -0.7e 0.7e 7 dly-len array@ make-all-pass { allpass2 }
    -0.7e 0.7e 8 dly-len array@ make-all-pass { allpass3 }
    -0.7e 0.7e 9 dly-len array@ make-all-pass { allpass4 }
    -0.7e 0.7e 11 dly-len array@ make-all-pass { allpass5 }
    -0.7e 0.7e 12 dly-len array@ make-all-pass { allpass6 }
    -0.7e 0.7e 13 dly-len array@ make-all-pass { allpass7 }
    -0.7e 0.7e 14 dly-len array@ make-all-pass { allpass8 }
    *verbose* if ." \  nrev on " rev-chans . ." in and " chans . ." out channels" cr then
    0e { f: rev }
    0e { f: outrev }
    start dur run
	0e rev-chans 0 u+do j i *reverb* in-any f+ loop to rev
	rev comb1 comb-1 rev comb2 comb-1 f+ rev comb3 comb-1 f+
	rev comb4 comb-1 f+ rev comb5 comb-1 f+ rev comb6 comb-1 f+
	allpass1 all-pass-1 allpass2 all-pass-1 allpass3 all-pass-1
	low one-pole allpass4 all-pass-1 to outrev
	outrev allpass5 all-pass-1 i outa-0
	chan2 if outrev allpass6 all-pass-1 i outb-0 then
	chan4 if
	    outrev allpass7 all-pass-1 i outc-0
	    outrev allpass8 all-pass-1 i outd-0
	then
    loop
    allpass1 mus-free
    allpass2 mus-free
    allpass3 mus-free
    allpass4 mus-free
    allpass5 mus-free
    allpass6 mus-free
    allpass7 mus-free
    allpass8 mus-free
    comb1 mus-free
    comb2 mus-free
    comb3 mus-free
    comb4 mus-free
    comb5 mus-free
    comb6 mus-free
;instrument

\ begin of examples from clm-2/fm.html
instrument: fm1 { f: start f: dur f: freq f: amp f: mc-ratio f: index ind-env }
    freq make-oscil-1 { cr }
    freq mc-ratio f* make-oscil-1 { md }
    index mc-ratio freq f* f* hz>radians { f: fm-index }
    ind-env amp dur make-env { ampf }
    ind-env fm-index dur make-env { indf }
    90e random 1e make-locsig { loc }
    start dur run  indf env  md oscil-0  f*  cr oscil-1  ampf env  f*  i loc locsig  loop
;instrument

instrument: fm2
    { f: start f: dur f: freq f: amp f: mc-ratio f: index f: carrier-phase f: mod-phase }
    freq carrier-phase make-oscil { cr }
    freq mc-ratio f* mod-phase make-oscil { md }
    index mc-ratio freq f* f* hz>radians { f: fm-index }
    90e random 1e make-locsig { loc }
    start dur run  fm-index md oscil-0  f*  cr oscil-1  amp  f*  i loc locsig  loop
;instrument

instrument: violin { f: start f: dur f: freq f: amp f: fm-index ind-env f: degree f: distance }
    freq hz>radians { f: frq-scl }
    frq-scl fm-index f* { f: maxdev }
    5e freq flog f/ maxdev f* { f: index1 }
    8.5e freq flog f- 3e freq 1000e f/ f+ f/ maxdev 3e f* f* { f: index2 }
    4e freq fsqrt f/ maxdev f* { f: index3 }
    freq make-oscil-1 { carrier }
    freq make-oscil-1 { fmosc1 }
    freq 3e f* make-oscil-1 { fmosc2 }
    freq 4e f* make-oscil-1 { fmosc3 }
    ind-env amp dur make-env { ampf }
    0e 1e 25e 0.4e 75e 0.6e 100e 0e 8 make-farray { index-env }
    index-env index1 dur make-env { indf1 }
    index-env index2 dur make-env { indf2 }
    index-env index3 dur make-env { indf3 }
    5e 0.0025e frq-scl f* make-triangle-wave-2 { pervib }
    16e 0.005e frq-scl f* make-rand-interp { ranvib }
    degree distance make-locsig { loc }
    start dur run
	pervib triangle-wave-0 ranvib rand-interp-0 f+ { f: vib }
	vib
	   vib    fmosc1 oscil-1 indf1 env f* f+
	3e vib f* fmosc2 oscil-1 indf2 env f* f+
	4e vib f* fmosc3 oscil-1 indf3 env f* f+ carrier oscil-1 ampf env f*
	i loc locsig
    loop
;instrument

instrument: violin-args { f: start f: dur f: freq f: amp args }
    freq hz>radians { f: frq-scl }
    frq-scl args :fm-index@ f* { f: maxdev }
    5e freq flog f/ maxdev f* { f: index1 }
    8.5e freq flog f- 3e freq 1000e f/ f+ f/ maxdev 3e f* f* { f: index2 }
    4e freq fsqrt f/ maxdev f* { f: index3 }
    freq make-oscil-1 { carrier }
    freq make-oscil-1 { fmosc1 }
    freq 3e f* make-oscil-1 { fmosc2 }
    freq 4e f* make-oscil-1 { fmosc3 }
    args :ind-env@ amp dur make-env { ampf }
    0e 1e 25e 0.4e 75e 0.6e 100e 0e 8 make-farray { index-env }
    index-env index1 dur make-env { indf1 }
    index-env index2 dur make-env { indf2 }
    index-env index3 dur make-env { indf3 }
    5e 0.0025e frq-scl f* make-triangle-wave-2 { pervib }
    16e 0.005e frq-scl f* make-rand-interp { ranvib }
    args :degree@ args :distance@ make-locsig { loc }
    start dur run
	pervib triangle-wave-0 ranvib rand-interp-0 f+ { f: vib }
	vib
	   vib    fmosc1 oscil-1 indf1 env f* f+
	3e vib f* fmosc2 oscil-1 indf2 env f* f+
	4e vib f* fmosc3 oscil-1 indf3 env f* f+ carrier oscil-1 ampf env f*
	i loc locsig
    loop
;instrument

\ violin generator for real time output
instrument: rt-violin { f: start f: dur f: freq f: amp f: fm-index ind-env }
    freq hz>radians { f: frq-scl }
    frq-scl fm-index f* { f: maxdev }
    5e freq flog f/ maxdev f* { f: index1 }
    8.5e freq flog f- 3e freq 1000e f/ f+ f/ maxdev 3e f* f* { f: index2 }
    4e freq fsqrt f/ maxdev f* { f: index3 }
    freq make-oscil-1 { carrier }
    freq make-oscil-1 { fmosc1 }
    freq 3e f* make-oscil-1 { fmosc2 }
    freq 4e f* make-oscil-1 { fmosc3 }
    ind-env amp dur make-env { ampf }
    0e 1e 25e 0.4e 75e 0.6e 100e 0e 8 make-farray { index-env }
    index-env index1 dur make-env { indf1 }
    index-env index2 dur make-env { indf2 }
    index-env index3 dur make-env { indf3 }
    5e 0.0025e frq-scl f* make-triangle-wave-2 { pervib }
    16e 0.005e frq-scl f* make-rand-interp { ranvib }
    lambda-create
    pervib , ranvib , fmosc1 , indf1 , fmosc2 , indf2 , fmosc3 , indf3 , carrier , ampf ,
    latestxt start dur times>samples
  does> { gen }
    gen @ triangle-wave-0 gen cell+ @ rand-interp-0 f+ { f: vib }
    vib
    vib    gen 2 cells + @ oscil-1 gen 3 cells + @ env f* f+
    3e vib f* gen 4 cells + @ oscil-1 gen 5 cells + @ env f* f+
    4e vib f* gen 6 cells + @ oscil-1 gen 7 cells + @ env f* f+
    gen 8 cells + @ oscil-1 gen 9 cells + @ env f*
;instrument

instrument: cascade
    { f: start f: dur f: freq f: amp f: modrat f: modind f: casrat f: casind f: caspha }
    freq make-oscil-1 { cr }
    freq modrat f* make-oscil-1 { md }
    freq casrat f* caspha make-oscil { ca }
    modind modrat f* freq f* hz>radians { f: fm-ind0 }
    casind casrat modrat f/ f* freq f* hz>radians { f: fm-ind1 }
    90e random 1e make-locsig { loc }
    start dur run ca oscil-0 fm-ind1 f* md oscil-1 fm-ind0 f* cr oscil-1 amp f* i loc locsig loop
;instrument
\ end of examples from clm-2/fm.html

\ clm-2/bird.ins
instrument: bird { f: start f: dur f: freq f: freq-skew f: amp freq-env amp-envel }
    freq make-oscil-1 { os }
    amp-envel amp dur make-env { amp-env }
    freq-env freq-skew hz>radians dur make-env { gls-env }
    90e random 1e make-locsig { loc }
    start dur run  amp-env env  gls-env env os oscil-1  f*  i loc locsig  loop
;instrument

\ clm-2/bigbird.ins
instrument: bigbird { f: start f: dur f: freq f: freq-skew f: amp freq-env amp-envel parts }
    freq make-oscil-1 { os }
    amp-envel amp dur make-env { amp-env }
    freq-env freq-skew hz>radians dur make-env { gls-env }
    parts normalize-partials 1 partials>polynomial { coeffs }
    90e random 1e make-locsig { loc }
    start dur run
	amp-env env  coeffs  gls-env env os oscil-1  polynomial  f*  i loc locsig
    loop
;instrument

\ clm-2/resflt.ins
instrument%
    cell% field resflt-noifun
    cell% field resflt-ampcosfun
    cell% field resflt-freqcosfun
    float% field resflt-freq1
    float% field resflt-r1
    float% field resflt-g1
    float% field resflt-freq2
    float% field resflt-r2
    float% field resflt-g2
    float% field resflt-freq3
    float% field resflt-r3
    float% field resflt-g3
end-struct resflt%

: :resflt-default { -- gen }
    resflt% :default! { gen }
    0e 0e 50e 1e 100e 0e 6 make-farray gen resflt-noifun !
    0e 0e 50e 1e 100e 0e 6 make-farray gen resflt-ampcosfun !
    0e 0e 100e 1e 4 make-farray gen resflt-freqcosfun !
    500e gen resflt-freq1 f!
    0.995e gen resflt-r1 f!
    0.1e gen resflt-g1 f!
    1000e gen resflt-freq2 f!
    0.995e gen resflt-r2 f!
    0.1e gen resflt-g2 f!
    2000e gen resflt-freq3 f!
    0.995e gen resflt-r3 f!
    0.1e gen resflt-g3 f!
    gen
;
: :noifun@ { gen -- w } gen resflt-noifun @ ;
: :ampcosfun@ { gen -- w } gen resflt-ampcosfun @ ;
: :freqcosfun@ { gen -- w } gen resflt-freqcosfun @ ;
: :freq1@ { gen -- r } gen resflt-freq1 f@ ;
: :r1@ { gen -- r } gen resflt-r1 f@ ;
: :g1@ { gen -- r } gen resflt-g1 f@ ;
: :freq2@ { gen -- r } gen resflt-freq2 f@ ;
: :r2@ { gen -- r } gen resflt-r2 f@ ;
: :g2@ { gen -- r } gen resflt-g2 f@ ;
: :freq3@ { gen -- r } gen resflt-freq3 f@ ;
: :r3@ { gen -- r } gen resflt-r3 f@ ;
: :g3@ { gen -- r } gen resflt-g3 f@ ;
: :noifun! { gen w -- gen } gen w resflt-noifun ! gen ;
: :ampcosfun! { gen w -- gen } gen w resflt-ampcosfun ! gen ;
: :freqcosfun! { gen w -- gen } gen w resflt-freqcosfun ! gen ;
: :freq1! { gen f: val -- gen } val gen resflt-freq1 f! gen ;
: :r1! { gen f: val -- gen } val gen resflt-r1 f! gen ;
: :g1! { gen f: val -- gen } val gen resflt-g1 f! gen ;
: :freq2! { gen f: val -- gen } val gen resflt-freq2 f! gen ;
: :r2! { gen f: val -- gen } val gen resflt-r2 f! gen ;
: :g2! { gen f: val -- gen } val gen resflt-g2 f! gen ;
: :freq3! { gen f: val -- gen } val gen resflt-freq3 f! gen ;
: :r3! { gen f: val -- gen } val gen resflt-r3 f! gen ;
: :g3! { gen f: val -- gen } val gen resflt-g3 f! gen ;

instrument: resflt-cos { f: start f: dur f: cosamp f: cosfreq1 f: cosfreq0 w: cosnum args }
    args :r1@ args :freq1@ make-ppolar { f1 }
    args :r2@ args :freq2@ make-ppolar { f2 }
    args :r3@ args :freq3@ make-ppolar { f3 }
    args :freqcosfun@ cosfreq1 cosfreq0 f- hz>radians dur make-env { frqf }
    args :ampcosfun@ cosamp dur make-env { ampf }
    cosfreq0 cosnum make-sum-of-cosines-2 { cn }
    args :g1@ { f: g1 }
    args :g2@ { f: g2 }
    args :g3@ { f: g3 }
    0e { f: input }
    90e random 1e make-locsig { loc }
    start dur run
	ampf env frqf env cn sum-of-cosines f* to input
	input g1 f* f1 two-pole
	input g2 f* f2 two-pole f+
	input g3 f* f3 two-pole f+
	i loc locsig
    loop
;instrument
instrument: resflt-noise { f: start f: dur f: ranfreq f: noiamp args }
    args :r1@ args :freq1@ make-ppolar { f1 }
    args :r2@ args :freq2@ make-ppolar { f2 }
    args :r3@ args :freq3@ make-ppolar { f3 }
    args :noifun@ noiamp dur make-env { ampf }
    ranfreq make-rand-1 { rn }
    args :g1@ { f: g1 }
    args :g2@ { f: g2 }
    args :g3@ { f: g3 }
    0e { f: input }
    90e random 1e make-locsig { loc }
    start dur run
	ampf env rn rand-0 f* to input
	input g1 f* f1 two-pole
	input g2 f* f2 two-pole f+
	input g3 f* f3 two-pole f+
	i loc locsig
    loop
;instrument
event: resflt-test ( -- )
    0e 1e 0.1e 200e 230e 10 :resflt-default resflt-cos
    0.5e 1e 10000e 0.01e :resflt-default resflt-noise
;event

\ clm-2/clm.html, section wave-train
instrument: fofins {
    f: start f: dur f: freq f: amp f: vib
    f: f0 f: a0 f: f1 f: a1 f: f2 f: a2
    ve ae }

    ae amp dur make-env { ampf }
    6e make-oscil-1 { vibr }
    ve vib dur make-env { vibenv }
    f0 hz>radians { f: frq0 }
    f1 hz>radians { f: frq1 }
    f2 hz>radians { f: frq2 }
    srate@ 22050 = if 100 else 200 then { foflen }
    two-pi foflen s>f f/ { f: win-freq }
    foflen make-farray-0 { foftab }
    foflen 0 u+do
	i s>f { f: idx }
	a0 idx frq0 f* fsin f*
	a1 idx frq1 f* fsin f* f+
	a2 idx frq2 f* fsin f* f+
	0.5e f*
	1e idx win-freq f* fcos f- f*
	i foftab farray!
    loop
    freq foftab make-wave-train-2 { wt0 }
    90e random 1e make-locsig { loc }
    start dur run ampf env vibenv env vibr oscil-0 f* wt0 wave-train f* i loc locsig loop
    foftab free-array
;instrument
event: fofins-test ( -- )
    0e 1e 100e 1e 4 make-farray { ve }
    0e 0e 25e 1e 75e 1e 100e 0e 8 make-farray { ae }
    0e 1e 270e 0.2e 0.001e 730e 0.6e 1090e 0.3e 2440e 0.1e ve ae fofins

    0e 0e 40e 0e 75e 0.2e 100e 1e 8 make-farray to ve
    0e 0e 0.5e 1e 3e 0.5e 10e 0.2e 20e 0.1e 50e 0.1e 60e 0.2e 85e 1e 100e 0e 18 make-farray to ae
    1.2e 4e 270e 0.2e 0.005e 730e 0.6e 1090e 0.3e 2440e 0.1e ve ae fofins

    0e 0e 0.5e 0.5e 3e .25e 6e 0.1e 10e .1e 50e .1e 60e 0.2e 85e 1e 100e 0e 18 make-farray to ae
    1.2e 4e 6e 5e f/ 540e f* 0.2e 0.005e 730e 0.6e 1090e 0.3e 2440e 0.1e ve ae fofins

    0e 0e 1e 3e 3e 1e 6e 0.2e 10e 0.1e 50e 0.1e 60e 0.2e 85e 1e 100e 0e 18 make-farray to ae
    1.2e 4e 135e 0.2e 0.005e 730e 0.6e 1090e 0.3e 2440e 0.1e ve ae fofins
;event

\ clm-2/clm.html, section formant
instrument: cross-synthesis { f: start f: dur d: file1 d: file2 f: amp }
    128 { fftsize } two-pi { f: r } 2 { lo } 0 { hi }
    file1 make-file>sample { fil1 }
    file2 make-file>sample { fil2 }
    fftsize 2/ { freq-inc }
    fftsize make-farray-0 { fdr }
    fftsize make-farray-0 { fdi }
    freq-inc make-farray-0 { diffs }
    fftsize make-farray-0 { spectr }
    0 { filptr }
    freq-inc { ctr }
    1e r fftsize s>f f/ f- { f: radius }
    srate@ fftsize / s>f { f: bin }
    fftsize make-array-0 { fs }
    hi 0= if freq-inc to hi then
    hi lo u+do radius i s>f bin f* make-formant-2 i fs array! loop
    90e random 1e make-locsig { loc }
    start dur run
	ctr freq-inc = if
	    fftsize 0 u+do filptr fil2 ina i fdr farray! filptr 1+ to filptr loop
	    fdi clear-farray
	    filptr freq-inc - to filptr
	    fdr fdi fft-2
	    fdr fdi rectangular>polar-2
	    freq-inc 0 u+do i fdr farray@ i spectr farray@ f- freq-inc s>f f/ i diffs farray! loop
	    0 to ctr
	then
	ctr 1+ to ctr
	freq-inc 0 u+do i spectr farray@ i diffs farray@ f+ i spectr farray! loop
	i fil1 ina { f: inval }
	0e hi lo u+do i spectr farray@ inval i fs array@ formant f* f+ loop
	amp f* i loc locsig
    loop
    fil1 close-snd
    fil2 close-snd
    fdr free-array
    fdi free-array
    diffs free-array
    spectr free-array
    fs free-array
;instrument
event: formant-test ( -- ) 0e 1e s" oboe.snd" s" fyow.snd" 0.1e cross-synthesis ;event

\ clm-2/ugex.ins
0e 697e 697e 697e 770e 770e 770e 852e 852e 852e 941e 941e 941e 13 make-farray value tt1
0e 1209e 1336e 1477e 1209e 1336e 1477e 1209e 1336e 1477e 1209e 1336e 1477e 13 make-farray value tt2
instrument: touch-tone { numbers }
    90e random 1e make-locsig { loc }
    numbers array-length 0 u+do
	i numbers array@ ?dup-if else 11 then { idx }
	idx tt1 farray@ make-oscil-1 { frq1 }
	idx tt2 farray@ make-oscil-1 { frq2 }
	i s>f 0.3e f* 0.2e run 0.25e frq1 oscil-0 frq2 oscil-0 f+ f* i loc locsig loop
    loop
;instrument
event: touch-tone-test ( -- ) 8 5 7 7 5 8 6 make-array touch-tone ;event

instrument: rt-touch-tone { f: start numb }
    numb ?dup-if else 11 then { idx }
    idx tt1 farray@ make-oscil-1
    idx tt2 farray@ make-oscil-1
    lambda-create , , latestxt start 0.3e f* 0.2e times>samples
  does> { gen }
    gen @ oscil-0 gen cell+ @ oscil-0 f+ 0.25e f*
;instrument
event: rt-touch-tone-test ( -- )
    8 5 7 7 5 8 6 make-array { data }
    data array-length 0 u+do i s>f i data array@ rt-touch-tone rt-run loop
;event

\ clm-2/insect.ins
instrument: fm-insect {
    f: start f: dur f: freq f: amp w: amp-env
    f: mod-freq f: mod-skew w: mod-freq-env f: mod-index w: mod-index-env
    f: fm-index f: fm-ratio }

    freq make-oscil-1 { carrier }
    mod-freq make-oscil-1 { fm1-osc }
    fm-ratio freq f* make-oscil-1 { fm2-osc }
    amp-env amp dur make-env { ampf }
    mod-index-env mod-index hz>radians dur make-env { indf }
    mod-freq-env mod-skew hz>radians dur make-env { modfrqf }
    fm-index fm-ratio f* freq f* hz>radians { f: fm2-amp }
    0e 0e { f: garble-in f: garble-out }
    90e random 1e make-locsig { loc }
    start dur run
	indf env   modfrqf env fm1-osc oscil-1   f* to garble-in
	fm2-amp   garble-in fm2-osc oscil-1   f* to garble-out
	ampf env   garble-out garble-in f+ carrier oscil-1   f*   i loc locsig
    loop
;instrument    
event: fm-insect-test ( -- )
    0e 0e 40e 1e 95e 1e 100e 0.5e 8 make-farray { locust }
    0e 1e 25e 0.7e 75e 0.78e 100e 1e 8 make-farray { bug-hi }
    0e 0e 25e 1e 75e 0.7e 100e 0e 8 make-farray { amp }

    0.000e 1.699e 4142.627e 0.015e amp 60e -16.707e locust 500.866e bug-hi 0.346e 0.5e fm-insect
    0.195e 0.233e 4126.284e 0.030e amp 60e -12.142e locust 649.490e bug-hi 0.407e 0.5e fm-insect
    0.217e 2.057e 3930.258e 0.045e amp 60e  -3.011e locust 562.087e bug-hi 0.591e 0.5e fm-insect
    2.100e 1.500e  900.627e 0.060e amp 40e -16.707e locust 300.866e bug-hi 0.346e 0.5e fm-insect
    3.000e 1.500e  900.627e 0.060e amp 40e -16.707e locust 300.866e bug-hi 0.046e 0.5e fm-insect
    3.450e 1.500e  900.627e 0.090e amp 40e -16.707e locust 300.866e bug-hi 0.006e 0.5e fm-insect
    3.950e 1.500e  900.627e 0.120e amp 40e -10.707e locust 300.866e bug-hi 0.346e 0.5e fm-insect
    4.300e 1.500e  900.627e 0.090e amp 40e -20.707e locust 300.866e bug-hi 0.246e 0.5e fm-insect
;event

\ clm-2/noise.ins
: attack-point { f: dur f: att f: dec }
    100e att f0= if dec f0= if dur else dur dec f- then 4e f/ else att then dur f/ f*
;
instrument: fm-noise {
    f: start f: dur f: freq0 f: amp w: ampfun f: ampat f: ampdc
    f: freq1 w: glissfun f: freqat f: freqdc
    f: rfreq0 f: rfreq1 w: rfreqfun f: rfreqat f: rfreqdc
    f: dev0 f: dev1 w: devfun f: devat f: devdc }

    freq0 make-oscil-1 { car }
    rfreq0 1e make-rand { modul }
    dev0 hz>radians { f: dev-0 }
    devfun 25e dur devat devdc attack-point 75e 100e dur devdc devat attack-point f-
    stretch-envelope dev1 dev0 f- hz>radians dur make-env { devf }
    ampfun 25e dur ampat ampdc attack-point 75e 100e dur ampdc ampat attack-point f-
    stretch-envelope amp dur make-env { ampf }
    glissfun 25e dur freqat freqdc attack-point 75e 100e dur freqdc freqat attack-point f-
    stretch-envelope freq1 freq0 f- hz>radians dur make-env { freqf }
    rfreqfun 25e dur rfreqat rfreqdc attack-point 75e 100e dur rfreqdc rfreqat attack-point f-
    stretch-envelope rfreq1 rfreq0 f- hz>radians dur make-env { rfrqf }
    90e random 1e make-locsig { loc }
    start dur run
	ampf env freqf env dev-0 devf env f+ rfrqf env modul rand f* f+ car oscil-1 f* i loc locsig
    loop
;instrument
event: fm-noise-test ( -- )
    0e 0e 100e 1e 4 make-farray { up-env }
    0e 1e 100e 0e 4 make-farray { down-env }
    0e 0e 25e 1e 75e 1e 100e 0e 8 make-farray { amp-env }

    0e 2e 500e 0.25e amp-env 0.1e 0.1e
    1000e up-env 0.1e 0.1e
    10e 1000e up-env 0e 0e
    100e 500e up-env 0e 0e fm-noise
;event

\ clm-2/pqw.ins
instrument: pqw { f: start f: dur f: sfreq f: cfreq f: amp ampfun indexfun parts }
    parts normalize-partials { nparts }
    sfreq half-pi make-oscil { sp-cos }
    sfreq make-oscil-1 { sp-sin }
    cfreq half-pi make-oscil { c-cos }
    cfreq make-oscil-1 { c-sin }
    nparts 0 partials>polynomial { sin-coeffs }
    nparts 1 partials>polynomial { cos-coeffs }
    ampfun amp dur make-env { amp-env }
    indexfun 1e dur make-env { ind-env }
    90e random 1e make-locsig { loc }
    0e 0e 0e 0e { f: vib f: ax f: fax f: yfax }
    cfreq sfreq f/ { f: r }
    5e 0.005e sfreq f* hz>radians make-triangle-wave-2 { tr }
    12e 0.005e sfreq f* hz>radians make-rand-interp { rn }
    start dur run
	tr triangle-wave-0 rn rand-interp-0 f+ to vib
	1e ind-env env fmin vib sp-cos oscil-1 f* to ax
	cos-coeffs ax polynomial to fax
	vib sp-sin oscil-1 sin-coeffs ax polynomial f* to yfax
	amp-env env
	vib r f* c-sin oscil-1 yfax f*
	vib r f* c-cos oscil-1 fax f* f- f* i loc locsig
    loop
;instrument
event: pqw-test ( -- )
    0e 5e 200e 1000e 0.2e
    0e 0e 25e 1e 100e 0e 6 make-farray
    0e 1e 100e 0e 4 make-farray
    2e 0.1e 3e 0.3e 6e 0.5e 6 make-farray pqw
;event

\ clm-2/anoi.ins
instrument: anoi { d: fname f: start f: dur fftsize f: amp-scaler f: R }
    fftsize 2/ { freq-inc }
    fftsize make-farray-0 { fdr }
    fftsize make-farray-0 { fdi }
    freq-inc 0 u+do 1e loop freq-inc make-farray { spectr }
    freq-inc 0 u+do 1e loop freq-inc make-farray { scales }
    freq-inc make-farray-0 { diffs }
    blackman2-window fftsize make-fft-window-2 { win }
    0 0 0e { kk samp f: amp }
    amp-scaler 4e f* mus-srate@ f/ { f: incr }
    fname make-file>sample { fil }
    1e R fftsize s>f f/ f- { f: radius }
    mus-srate@ fftsize s>f f/ { f: bin }
    freq-inc 0 u+do radius i s>f bin f* make-formant-2 loop freq-inc make-array { fs }
    90e random 1e make-locsig { loc }
    start dur run
	samp fil file>sample-0 { f: inval } samp 1+ to samp
	inval kk fdr farray! kk 1+ to kk
	amp amp-scaler f< if amp incr f+ to amp then
	kk fftsize >= if
	    0 to kk
	    fdr fdi win 1 spectrum
	    freq-inc 0 u+do
		0.9e i spectr farray@ f* 0.1e i fdr farray@ f* f+ i spectr farray!
		i spectr farray@ i fdr farray@ f>= if
		    i scales farray@ fftsize negate s>f f/
		else
		    i fdr farray@ i spectr farray@ f- i fdr farray@ f/ i scales farray@ f-
		    fftsize s>f f/
		then i diffs farray!
	    loop
	then
	0e { f: outval }
	freq-inc 1 u+do
	    i scales farray@ { f: curscl }
	    outval curscl inval i fs array@ formant f* f+ to outval
	    curscl i diffs farray@ f+ i scales farray!
	loop
	amp outval f* i loc locsig
    loop
    fil close-snd
    fdr free-array
    fdi free-array
    spectr free-array
    scales free-array
    diffs free-array
;instrument
instrument: anoi-0 { d: fname f: start f: dur } fname start dur 128 1e two-pi anoi ;instrument
event: anoi-test ( -- ) s" fyow.snd" 0e 1e anoi-0 ;event

: get-optimum-c { f: s f: o f: p -- t c }
    o 1/f s o fsin f* 1e s f- s o fcos f* f+ fatan2 f* { f: pa }
    p pa f- f>s { tmp_int } tmp_int 0= if 1 to tmp_int then
    p pa f- tmp_int s>f f- { f: pc }
    begin pc 0.1e f< while tmp_int 1 - to tmp_int pc 1e f+ to pc repeat
    tmp_int
    o fsin o pc f* fsin f- o o pc f* f+ fsin f/
;
: tune-it { f: f f: s1 -- s c t }
    mus-srate@ f f/ { f: p }
    s1 f0= if 0.5e else s1 then { f: s }
    f hz>radians { f: o }
    s o p get-optimum-c { t1 f: c1 }
    1e s f- o p get-optimum-c { t2 f: c2 }
    s 0.5e f<> c1 fabs c2 fabs f< and if 1e s f- c1 t1 else s c2 t2 then
;
instrument: pluck { f: start f: dur f: freq f: amp f: weighting f: lossfact }
    freq weighting tune-it { f: wt0 f: c dlen }
    lossfact f0= if 1e else 1e lossfact fmin then { f: lf }
    wt0 f0= if 0.5e else 1e wt0 fmin then { f: wt }
    lf 1e wt f- f* lf wt f* make-one-zero { allp }
    c 1e make-one-zero { feedb }
    dlen 0 u+do 1e 2e gfm-random f- loop dlen make-farray { tab }
    90e random 1e make-locsig { loc }
    start dur run
	i dlen mod tab farray@ { f: val }
	1e c f- val allp one-zero feedb one-zero f* i dlen mod tab farray!
	amp val f* i loc locsig
    loop
;instrument
event: pluck-test ( -- ) 0.05e 0.1e 330e 0.1e 0.95e 0.95e pluck ;event

\ instruments.fs ends here
